# Student-Teacher-Booking-Appointment
<br>Made using HTML, CSS, JS, Bootstrap and Firebase(BaaS: Backend As A Service).
<br>It includes Login, Register page and a realtime Database(NoSQL) table that gets updated using Firebase in the backend.
<br>Successfully implemented all the CRUD operations.
<br>So, a teacher can successfully login and can update the information corresponding to his/her students. And similarly the students can login or register and alter the informations corresponding to them.
